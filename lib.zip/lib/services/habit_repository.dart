import 'dart:convert';

import 'package:habit_tracker/models/habit_model.dart';
import 'package:habit_tracker/services/shared_preferences_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HabitRepository {
  static const _storageKey = 'habits_v1';

  SharedPreferencesHelper helper = SharedPreferencesHelper();

  Future<List<HabitModel>> loadHabits() async {
    return await helper.getStringList(_storageKey);
  }

  Future<void> saveHabits(List<HabitModel> habits) async {
    helper.setStringList(_storageKey, habits);
  }
}
